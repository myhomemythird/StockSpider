package org.richardliao.springmongodb;

import java.util.Date;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.ApplicationContext;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.data.document.mongodb.MongoTemplate;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import com.mongodb.Mongo;

import org.richardliao.springmongodb.repo.UserRepo;

/**
 * Hello world!
 *
 */
public class App
{
    @Autowired
    private MongoTemplate mongoTemplate;

    //@Autowired
    //private UserRepo repo;
    
    public static void main( String[] args )
    {
	App app = new App();
	//ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("mongodb.xml");
	ApplicationContext context = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
        app.setMongoTemplate((MongoTemplate) context.getBean(MongoTemplate.class));
        System.out.println( "Spring MongoDB Test..." );
	User user = new User();
	user.setName("Richard Liao " + new Date());
	user.setAge(30);
	app.insert(user);
	UserRepo repo = (UserRepo)context.getBean("userRepo");
	System.out.println(repo.findAll());
    }

    public void setMongoTemplate(MongoTemplate mongoTemplate) {
	this.mongoTemplate = mongoTemplate;
    }

    public void insert(User user) {
	System.out.println( "MongoTemplate: " + mongoTemplate);
	mongoTemplate.insert(user);
    }

    @Configuration
    @EnableMongoRepositories("org.richardliao.springmongodb.repo")
    public static class SpringMongoConfig extends AbstractMongoConfiguration {
	@Override
	public @Bean Mongo mongo() throws Exception {
	    return new Mongo("localhost");
	}
	
	@Override
	public @Bean MongoTemplate mongoTemplate() throws Exception {
	    return new MongoTemplate(mongo(),"test");
	}

	@Override
	public String getDatabaseName() {
	    return "test1";
	}
    }
}
